            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">

                   
                    <div id="sidebar-menu">
                        <ul>
                        	<li class="menu-title">Navigatsiya</li>

                            <li class="has_sub">
                                <a href="dashboard.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Boshqaruv paneli </span> </a>
                         
                            </li>
<?php if($_SESSION['utype']=='1'):?>
  <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Sub-adminlar </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-subadmins.php">Sub-adminni qo'shing</a></li>
                                    <li><a href="manage-subadmins.php">Sub-adminni boshqarish</a></li>
                                </ul>
                            </li>
<?php endif;?>
               


                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Turkum </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<li><a href="add-category.php">Turkum qo'shish</a></li>
                                    <li><a href="manage-categories.php">Turkumni boshqarish</a></li>
                                </ul>
                            </li>

    <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Pastki toifa </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-subcategory.php">Pastki toifani qo'shish</a></li>
                                    <li><a href="manage-subcategories.php">Pastki toifani boshqarish</a></li>
                                </ul>
                            </li>               
  <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Xabarlar  </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-post.php">Xabarlarni qo'shish</a></li>
                                    <li><a href="manage-posts.php">Xabarlarni boshqarish</a></li>
                                     <li><a href="trash-posts.php">O'chirgan xabarlar</a></li>
                                </ul>
                            </li>  
                     

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Sahifalar </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="aboutus.php">Biz haqimizda</a></li>
                                    <li><a href="contactus.php">Biz bilan bog'lanish</a></li>
                                </ul>
                            </li>
   <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Izohlar </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                  <li><a href="unapprove-comment.php">Tasdiqlanish kutilmoqda </a></li>
                                    <li><a href="manage-comments.php">Tasdiqlangan sharhlar</a></li>
                                </ul>
                            </li>   

                        </ul>
                    </div>
                    
                    <div class="clearfix"></div>

                    <div class="help-box">
                        <h5 class="text-muted m-t-0">Yordam uchunmi?</h5>
                        <p class=""><span class="text-custom">Email:</span> <br/> </p>
                    </div>

                </div>
              

            </div>