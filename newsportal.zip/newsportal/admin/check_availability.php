<?php 
require_once("includes/config.php");

if(!empty($_POST["username"])) {
	$uname= $_POST["username"];
$query=mysqli_query($con,"select AdminuserName from tbladmin where AdminuserName='$uname'");		
$row=mysqli_num_rows($query);
if($row>0){
echo "<span style='color:red'> Foydalanuvchi nomi allaqachon mavjud. Boshqa foydalanuvchi nomi bilan harakat qilib ko'ring</span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
} else{
echo "<span style='color:green'> Ro'yxatdan o'tish uchun foydalanuvchi nomi mavjud.</span>";
echo "<script>$('#submit').prop('disabled',false);</script>";
}
}
?>
